<h3 class="title">Menu Layout Builder<span class="close"></span></h3>

<div class="main text-center">
    <iframe src="<?php echo esc_url( Thim_Menu_Manager::get_base_link_page_builder() ); ?>{{data.menu_id}}" width="100%" height="500" frameborder="0" allowfullscreen></iframe>
</div>
